##OPEN API STUFF
OPENAI_API_KEY = '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'



## FLASK STUFF
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "this-is-a-super-secret-key"


config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}
